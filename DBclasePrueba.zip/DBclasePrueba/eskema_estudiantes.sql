-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: eskema
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `estudiantes`
--

DROP TABLE IF EXISTS `estudiantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estudiantes` (
  `IdEstudiante` int NOT NULL AUTO_INCREMENT,
  `CedulaEstu` varchar(20) NOT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Apellido` varchar(50) DEFAULT NULL,
  `Programa` varchar(100) DEFAULT NULL,
  `Correo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IdEstudiante`),
  UNIQUE KEY `CedulaEstu` (`CedulaEstu`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estudiantes`
--

LOCK TABLES `estudiantes` WRITE;
/*!40000 ALTER TABLE `estudiantes` DISABLE KEYS */;
INSERT INTO `estudiantes` VALUES (1,'10010001','Valeria','González','Ingeniería de Sistemas','valeria.gonzalez@universidad.edu.co'),(2,'10010002','Andrés','Martínez','Administración de Empresas','andres.martinez@universidad.edu.co'),(3,'10010003','Camilo','Ríos','Psicología','camilo.rios@universidad.edu.co'),(4,'10010004','Laura','Castro','Enfermería','laura.castro@universidad.edu.co'),(5,'10010005','Sofía','Mejía','Arquitectura','sofia.mejia@universidad.edu.co'),(6,'10010006','Juan','Hernández','Derecho','juan.hernandez@universidad.edu.co'),(7,'10010007','Isabella','Torres','Contaduría','isabella.torres@universidad.edu.co'),(8,'10010008','David','Ramírez','Diseño Gráfico','david.ramirez@universidad.edu.co'),(9,'10010009','Manuela','Vargas','Medicina','manuela.vargas@universidad.edu.co'),(10,'10010010','Felipe','López','Ingeniería Civil','felipe.lopez@universidad.edu.co'),(11,'10010011','Daniela','Cruz','Ingeniería Ambiental','daniela.cruz@universidad.edu.co'),(12,'10010012','Esteban','Suárez','Economía','esteban.suarez@universidad.edu.co'),(13,'10010013','Carolina','Ortiz','Ingeniería Industrial','carolina.ortiz@universidad.edu.co'),(14,'10010014','Julián','Gómez','Biología','julian.gomez@universidad.edu.co'),(15,'10010015','Paula','Morales','Nutrición','paula.morales@universidad.edu.co'),(16,'10010016','Santiago','Pardo','Matemáticas','santiago.pardo@universidad.edu.co'),(17,'10010017','María','Reyes','Enfermería','maria.reyes@universidad.edu.co'),(18,'10010018','Alejandro','Silva','Ingeniería Electrónica','alejandro.silva@universidad.edu.co'),(19,'10010019','Diana','Quintero','Contaduría','diana.quintero@universidad.edu.co'),(20,'10010020','Tomás','Nieto','Ingeniería Mecánica','tomas.nieto@universidad.edu.co'),(21,'10010021','Martina','Cárdenas','Derecho','martina.cardenas@universidad.edu.co'),(22,'10010022','Emilio','Sánchez','Física','emilio.sanchez@universidad.edu.co'),(23,'10010023','Gabriela','Jiménez','Medicina','gabriela.jimenez@universidad.edu.co'),(24,'10010024','Sebastián','Camacho','Ingeniería Química','sebastian.camacho@universidad.edu.co'),(25,'10010025','Lucía','Rincón','Psicología','lucia.rincon@universidad.edu.co'),(26,'10010026','Pablo','Mendoza','Arquitectura','pablo.mendoza@universidad.edu.co'),(27,'10010027','Valentina','Ruiz','Ingeniería de Sistemas','valentina.ruiz@universidad.edu.co'),(28,'10010028','Miguel','Peña','Ingeniería Industrial','miguel.pena@universidad.edu.co'),(29,'10010029','Fernanda','Luna','Diseño Gráfico','fernanda.luna@universidad.edu.co'),(30,'10010030','Jorge','Ibáñez','Administración de Empresas','jorge.ibanez@universidad.edu.co'),(31,'10010031','Natalia','Salazar','Contaduría','natalia.salazar@universidad.edu.co'),(32,'10010032','Simón','Valencia','Matemáticas','simon.valencia@universidad.edu.co'),(33,'10010033','Juliana','Cifuentes','Ingeniería Civil','juliana.cifuentes@universidad.edu.co'),(34,'10010034','Cristian','Guerra','Economía','cristian.guerra@universidad.edu.co'),(35,'10010035','Daniela','Bermúdez','Enfermería','daniela.bermudez@universidad.edu.co'),(36,'10010036','Andrés','Vega','Ingeniería Mecánica','andres.vega@universidad.edu.co'),(37,'10010037','Tatiana','Navarro','Ingeniería Electrónica','tatiana.navarro@universidad.edu.co'),(38,'10010038','Oscar','León','Física','oscar.leon@universidad.edu.co'),(39,'10010039','Catalina','Prieto','Psicología','catalina.prieto@universidad.edu.co'),(40,'10010040','Felipe','Soto','Ingeniería Química','felipe.soto@universidad.edu.co'),(41,'10010041','Ana','Rojas','Comunicación Social','ana.rojas@universidad.edu.co'),(42,'10010042','Ricardo','Franco','Derecho','ricardo.franco@universidad.edu.co'),(43,'10010043','Elisa','Campos','Arquitectura','elisa.campos@universidad.edu.co'),(44,'10010044','Mauricio','Gaitán','Ingeniería Industrial','mauricio.gaitan@universidad.edu.co'),(45,'10010045','Camila','Salamanca','Ingeniería de Sistemas','camila.salamanca@universidad.edu.co'),(46,'10010046','Iván','Reina','Medicina','ivan.reina@universidad.edu.co'),(47,'10010047','Paola','Acosta','Diseño Gráfico','paola.acosta@universidad.edu.co'),(48,'10010048','Hugo','Montoya','Contaduría','hugo.montoya@universidad.edu.co'),(49,'10010049','Carla','Nieto','Ingeniería Ambiental','carla.nieto@universidad.edu.co'),(50,'10010050','Elena','Serrano','Comunicación Social','elena.serrano@universidad.edu.co');
/*!40000 ALTER TABLE `estudiantes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-21 21:21:27
